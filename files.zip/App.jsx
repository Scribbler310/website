import { useEffect, useState } from 'react'
import MatrixRain from './MatrixRain.jsx'

const TABS = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'projects', label: 'Projects' },
  { id: 'contact', label: 'Contact' },
]

function Home() {
  const [message, setMessage] = useState('Loading...')

  useEffect(() => {
    fetch('/api/hello')
      .then((res) => {
        if (!res.ok) throw new Error(`Request failed: ${res.status}`)
        return res.json()
      })
      .then((data) => setMessage(data.message))
      .catch(() => setMessage('Could not reach the API. Is the server running?'))
  }, [])

  return (
    <>
      <h1>Website</h1>
      <p className="terminal-line">{message}</p>
    </>
  )
}

function About() {
  return (
    <>
      <h1>About</h1>
      <p>Replace this with a few words about you or your site.</p>
    </>
  )
}

function Projects() {
  return (
    <>
      <h1>Projects</h1>
      <p>Your projects will show up here.</p>
    </>
  )
}

function Contact() {
  return (
    <>
      <h1>Contact</h1>
      <p>Add your email or social links here.</p>
    </>
  )
}

const PAGES = { home: Home, about: About, projects: Projects, contact: Contact }

function App() {
  const [activeTab, setActiveTab] = useState('home')
  const Page = PAGES[activeTab]

  return (
    <>
      <MatrixRain />
      <div className="layout">
        <nav className="sidebar" aria-label="Main">
          <div className="brand">&gt;_ website</div>
          <ul>
            {TABS.map((tab) => (
              <li key={tab.id}>
                <button
                  type="button"
                  className={tab.id === activeTab ? 'tab active' : 'tab'}
                  aria-current={tab.id === activeTab ? 'page' : undefined}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.label}
                </button>
              </li>
            ))}
          </ul>
        </nav>
        <main>
          <Page />
        </main>
      </div>
    </>
  )
}

export default App
