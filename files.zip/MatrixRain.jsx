import { useEffect, useRef } from 'react'

const CHARS = 'アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789ABCDEF<>/{}[]$#%'
const FONT_SIZE = 16

// Falling green characters drawn on a fixed full-screen canvas behind the page.
function MatrixRain() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)')
    let drops = []
    let timer

    function resize() {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      const columns = Math.ceil(canvas.width / FONT_SIZE)
      drops = Array.from({ length: columns }, () => Math.random() * -50)
      ctx.fillStyle = '#000'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
    }

    function draw() {
      // Translucent black layer makes older characters fade into a trail
      ctx.fillStyle = 'rgba(0, 0, 0, 0.08)'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      ctx.fillStyle = '#00ff41'
      ctx.font = `${FONT_SIZE}px monospace`

      drops.forEach((y, i) => {
        const char = CHARS[Math.floor(Math.random() * CHARS.length)]
        ctx.fillText(char, i * FONT_SIZE, y * FONT_SIZE)
        if (y * FONT_SIZE > canvas.height && Math.random() > 0.975) {
          drops[i] = 0
        } else {
          drops[i] = y + 1
        }
      })
    }

    function start() {
      clearInterval(timer)
      if (!reduceMotion.matches) timer = setInterval(draw, 50)
    }

    resize()
    start()
    window.addEventListener('resize', resize)
    reduceMotion.addEventListener('change', start)

    return () => {
      clearInterval(timer)
      window.removeEventListener('resize', resize)
      reduceMotion.removeEventListener('change', start)
    }
  }, [])

  return <canvas ref={canvasRef} className="matrix-rain" aria-hidden="true" />
}

export default MatrixRain
